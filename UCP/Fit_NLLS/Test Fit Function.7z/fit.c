// ******************************************************************
// ******************************************************************
// *****                                                        *****
// *****                      MOTfit lib header                 *****
// *****                                                        *****
// ******************************************************************
// ******************************************************************


#include <utility.h>
#include <userint.h>
#include <ansi_c.h>
#include <fit_levmar.h>
#include <Example.h> 

			   int handle;

///////////////////////

/*
[0] = Amplitude
[1] = X0
[2] = Sigma
[3] = Background
*/
void fit_function3(double *fit_parameter, double *ydata, int number_fit_parameters, int number_data_points, void *additional_data)
{
	int i;
	
	for (i=0; i<number_data_points; i++)
	{  
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma))+B 
		ydata[i] = 1e4*fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2]))+1e4*fit_parameter[3];
	}
}

void jacobian_fit_function3(double *fit_parameter, double *jacobian, int number_fit_parameters, int number_data_points, void *additional_data)
{
	int i, j;
	
	for (i=j=0; i<number_data_points; i++)
	{
		//exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma))
		jacobian[j++] = 1e4*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/(2*fit_parameter[2]*fit_parameter[2]));
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma)) * (X-X0)/(Sigma*Sigma)
		jacobian[j++] = 1e4*fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2])) * (i-fit_parameter[1]) / (fit_parameter[2]*fit_parameter[2]);
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma)) * (X-X0)*(X-X0)/(Sigma*Sigma*Sigma)
		jacobian[j++] = 1e4*fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2])) * (i-fit_parameter[1])*(i-fit_parameter[1]) / (fit_parameter[2]*fit_parameter[2]*fit_parameter[2]);
		jacobian[j++] = 1e4;
	}
}

/*
void check_jacobian(void)
{
	#define number_of_data_points 40
	#define number_fit_parameters 4
	double fit_parameter[number_fit_parameters], x[number_of_data_points];
	int i;
	
	dlevmar_chkjac(fit_function, jacobian_fit_function, fit_parameter, number_fit_parameters, number_of_data_points, NULL, x);
	
	for (i=0; i<number_of_data_points; i++)
	{
		printf("Jacobian: %.2f\n", x[i]);
	}
	//if Jacobian <0.5, than an element contains an error
}
*/


//int mot_DoFit(datset *dataset, datset *fit, double *pos, double *sigma, double *bgrnd, double *ampl)
int mot_DoFit(double *ydata, int datapoints)
{
	#define number_fit_parameters 4
	const int number_of_iterations = 500;
	double fit_parameter[number_fit_parameters], info[LM_INFO_SZ];
	
	int ret; 

	
	//double opts[LM_OPTS_SZ];
	
	fit_parameter[0]= 4000000/1e4;//Amplitude
	fit_parameter[1]= 100;	//X0
	fit_parameter[2]= 30;			//Sigma
	fit_parameter[3]= 200000/1e4;		//Background

	
	/* optimization control parameters; passing to levmar NULL instead of opts reverts to defaults */
	//opts[0]=LM_INIT_MU; opts[1]=LM_STOP_THRESH; opts[2]=LM_STOP_THRESH; opts[3]=LM_STOP_THRESH;
	//opts[0]=LM_INIT_MU; opts[1]=1E-15; opts[2]=1E-15; opts[3]=1E-20;
	//opts[0]=LM_INIT_MU; opts[1]=1E-5; opts[2]=1E-5; opts[3]=1E-10;

	/* invoke the optimization function */
	ret=dlevmar_der(fit_function3, jacobian_fit_function3, fit_parameter, ydata, number_fit_parameters, datapoints, number_of_iterations, NULL, info, NULL, NULL, NULL);

	
	//PlotY(handle, PANEL_GRAPH, ydata, datapoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED); 
	//fit_function3(fit_parameter, ydata, number_fit_parameters, datapoints, NULL);
	//PlotY(handle, PANEL_GRAPH, ydata, datapoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_GREEN); 
	printf("1: %.2f %.2f %.2f %.2f\n", fit_parameter[0], fit_parameter[1], fit_parameter[2], fit_parameter[3]);
	return 0;
}


//int mot_DoFit(datset *dataset, datset *fit, double *pos, double *sigma, double *bgrnd, double *ampl)
int mot_DoFit2(double *ydata, int datapoints)
{
	#define number_fit_parameters 4
	const int number_of_iterations = 500;
	double fit_parameter[number_fit_parameters], info[LM_INFO_SZ];
	
	int ret; 

	
	double opts[LM_OPTS_SZ];
	
	fit_parameter[0]= 4000000/1e4;//Amplitude
	fit_parameter[1]= 100;	//X0
	fit_parameter[2]= 30;			//Sigma
	fit_parameter[3]= 200000/1e4;		//Background

	
	/* optimization control parameters; passing to levmar NULL instead of opts reverts to defaults */
	//opts[0]=LM_INIT_MU; opts[1]=LM_STOP_THRESH; opts[2]=LM_STOP_THRESH; opts[3]=LM_STOP_THRESH;
	//opts[0]=LM_INIT_MU; opts[1]=1E-15; opts[2]=1E-15; opts[3]=1E-20;
	opts[0]=1e-0; opts[1]=LM_STOP_THRESH; opts[2]=LM_STOP_THRESH; opts[3]=LM_STOP_THRESH;

	/* invoke the optimization function */
	ret=dlevmar_der(fit_function3, jacobian_fit_function3, fit_parameter, ydata, number_fit_parameters, datapoints, number_of_iterations, opts, info, NULL, NULL, NULL);
	printf("2: %.2f %.2f %.2f %.2f\n", fit_parameter[0], fit_parameter[1], fit_parameter[2], fit_parameter[3]);
	return 0;
}








void fitfunc(int handlea)
{
	
	handle = handlea;
	double time;
	/*
	double x[299] = {297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,
319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,
341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,
363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,
385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,
407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,
429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,
451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,
473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,
495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,
517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,
539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,
561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,
583,584,585,586,587,588,589,590,591,592,593,594,595}; */

double y1[299] = {347648,345600,325120,346624,343552,342528,356352,346112,354816,353280,365056,370176,356864,356864,350208,365056,373248,
349696,354816,366592,376320,369152,368640,359424,369664,367104,377344,362496,387072,375296,393216,388096,386048,375808,
387584,387584,403968,388608,403456,398336,401408,415232,392704,411136,412672,423424,431616,408064,425472,434176,435200,
427008,427520,421888,445440,462848,458240,457728,477184,464384,453632,458752,452608,456704,462336,488960,504320,475136,
481280,490496,499200,503808,494592,515072,544256,524800,537600,518144,539648,529408,557568,552448,556032,583168,579584,
582656,611328,592896,622080,615936,638464,649728,658944,692224,703488,741888,757760,765952,785920,801792,821760,893440,
889856,893952,952320,984576,1012736,1024000,1055232,1108992,1163264,1172992,1229312,1246720,1293824,1339392,1365504,
1382400,1439232,1483264,1544704,1566720,1586176,1650688,1655808,1710592,1767936,1762304,1771520,1841152,1848832,1869312,
1891840,1902080,1945088,1972736,1995776,2011648,2037760,2073088,2101248,2129920,2139648,2135552,2183680,2208256,2242048,
2232832,2266624,2279424,2301440,2328064,2305536,2336768,2366976,2400256,2419712,2428928,2452480,2467840,2509824,2494464,
2522624,2520064,2571264,2562048,2606080,2566656,2587136,2610176,2604544,2581504,2564608,2563584,2541568,2523648,2534400,
2487808,2487296,2442240,2426368,2393600,2364928,2320384,2299904,2255360,2225152,2155520,2132480,2094592,2033664,2009088,
1945088,1866752,1868288,1805824,1756160,1685504,1626624,1591296,1547264,1510912,1434624,1400320,1345024,1300480,1272832,
1192960,1152000,1131520,1075200,1052672,994816,971264,913920,891392,882688,799744,778240,762880,728576,710656,683520,
666112,644608,636416,617984,573952,558592,536064,540160,546816,520192,502272,496640,488960,473600,461312,452608,445952,
461312,452096,429056,424960,429056,418304,435200,391168,400896,396288,404480,417792,386560,389120,401920,408576,408064,
365568,379392,390144,394752,397312,391168,389632,385024,407552,389632,377856,385536,372224,401920,377856,392192,381440,
373760,379392,385024,362496,388096,356352,384000,390656,375808,370688,379904,390144,380928,354816,372736,367616,388096,
378368,371712,378368,366592,374784,387584,370688,382976};

/*
double y2[299] = {428032,413184,420352,419328,421376,425984,426496,451072,429568,439296,437248,414208,439296,436736,423936,427520,
425472,431104,442880,429568,423936,434176,416256,422912,419840,440832,440832,455168,440320,444928,444416,428032,
438272,434688,450560,429056,452608,442368,452608,448512,458752,450048,456704,449536,456192,438272,453632,450048,
449536,459264,453632,458752,471552,471040,467456,464896,479232,479232,465408,486400,478208,489984,463872,484352,
489472,487424,496128,500736,485376,494592,498688,495104,495616,491520,497152,519168,521216,522752,523776,534528,
537600,540672,544256,524288,529408,542720,546816,563200,563200,574464,571904,581632,595968,598528,594432,598528,
613888,622592,643072,649728,674304,688128,684032,687616,699392,710144,724992,757760,775168,791552,809984,846336,
843776,865792,904704,920064,936960,970752,999936,1018880,1056256,1075712,1100800,1124864,1166848,1170944,1200640,
1241600,1258496,1288192,1306624,1345536,1364480,1403392,1434112,1467904,1472000,1509376,1523200,1567744,1589760,
1614848,1630720,1662976,1724416,1723904,1776128,1784320,1830400,1839616,1879552,1887744,1953792,1957376,1970688,
1969152,2023936,2047488,2067456,2075648,2104320,2084864,2129408,2135040,2162176,2163200,2169856,2164224,2181632,
2169856,2173440,2181632,2172928,2178048,2198016,2160640,2152448,2150400,2151424,2137088,2126336,2087424,2092544,
2068480,2059776,2050048,2006016,1988608,1985536,1971712,1956352,1915904,1910784,1889280,1870336,1868288,1849344,
1810432,1786880,1767936,1777152,1743360,1734144,1701888,1684480,1643008,1659392,1621504,1605632,1605632,1550848,
1533952,1518080,1503232,1486848,1448448,1427968,1402368,1391616,1366016,1365504,1316352,1291776,1315840,1267200,
1254400,1249792,1210880,1176576,1158656,1128960,1101312,1090048,1063936,1053184,1037824,1019392,1019904,999424,
958976,967168,932864,890880,898560,888832,869888,851456,821248,832000,795648,802816,775168,767488,757248,737280,
723456,721920,688640,685056,665600,663040,645120,642560,620032,631296,611328,601600,595968,584192,552448,582144,
546304,555520,539648,530432,508928,501248,504832,487424,480256,477696,459776,451072,446464,467456,443904,446464,
436736,425984,424960,403456,413184,402432,394240,409088,396288,397312,389632,394752};
*/ 

		mot_DoFit(y1, 299);

	  time = Timer();
	  mot_DoFit(y1, 299);
	  mot_DoFit(y1, 299);
	  mot_DoFit(y1, 299);
	  mot_DoFit(y1, 299);
	  printf("%.2f\n",Timer()-time);
	  
	  
	  time = Timer();
	  mot_DoFit2(y1, 299);
	  mot_DoFit2(y1, 299);
	  mot_DoFit2(y1, 299);
	  mot_DoFit2(y1, 299);
	  printf("%.2f\n",Timer()-time);

}





/*
Options
 0  mu		 	The scale factor for initial mu.
 				The algorithm is not very sensitive to the choice of initial mu, but as a rule of thumb, one should
				use a small value, eg mu =1e-6 if p is believed to be a good approximation to f(p)
				Otherwise, use mu =10e-3 or even mu =1.
				From METHODS FOR NON-LINEAR LEAST SQUARES PROBLEMS, 2nd Edition, April 2004, K. Madsen, H.B. Nielsen, O. Tingleff
 1  epsilon1	Stopping threshold for ||J^T e||_inf 
 				Which is the gradient of e w.r.t p at the current estimate of p, with e=y-f(p)
 2  epsilon2	Stopping threshold for ||Dp||_2
 				Which is the amount by which p is currently being shifted at each iteration
 3  epsilon3	Stopping threshold for ||e||_2
 				With e=y-f(p), a measure of the error between the model function at the current estimate for p and the data
*/	
	
	


