/*------------------------------------------------------------------------------------------------------------------------
 *  File 		Example.c
 *  Author		Wouter Engelen
 *	Version		September 2010
 *		
 *  
 *
------------------------------------------------------------------------------------------------------------------------*/

// Include files
#include "toolbox.h"
#include "Example.h"

#include <fit_levmar.h>
#include <fit.h>   

static int panelHandle; 

//Global variables
   

#ifndef LM_DBL_PREC
#error Example program assumes that levmar has been compiled with double precision, see LM_DBL_PREC!
#endif


/* the following macros concern the initialization of a random number generator for adding noise */
#undef REPEATABLE_RANDOM
#define DBL_RAND_MAX (double)(RAND_MAX)

#ifdef _MSC_VER // MSVC
#include <process.h>
#define GETPID  _getpid
#elif defined(__GNUC__) // GCC
#include <sys/types.h>
#include <unistd.h>
#define GETPID  getpid
#else
//#warning Do not know the name of the function returning the process id for your OS/compiler combination
#define GETPID  0
#endif /* _MSC_VER */

#ifdef REPEATABLE_RANDOM
#define INIT_RANDOM(seed) srandom(seed)
#else
#define INIT_RANDOM(seed) srandom((int)GETPID()) // seed unused
#endif
 




/* Gaussian noise with mean m and variance s, uses the Box-Muller transformation */
double gNoise(double m, double s)
{

	double r1, r2, val;

  r1=((double)rand())/DBL_RAND_MAX;
  r2=((double)rand())/DBL_RAND_MAX;

  val=sqrt(-2.0*log(r1))*cos(2.0*3.1415*r2);

  val=s*val+m;

  return val;
}


/*
[0] = Amplitude
[1] = X0
[2] = Sigma
[3] = Background
*/

//Model(X,A,B,X0,SigmaX) ((A)*exp(-(((X)-(X0))*((X)-(X0)))/(2*(SigmaX)*(SigmaX)))+(B))

void fit_function(double *fit_parameter, double *x, int number_fit_parameters, int number_data_points, void *additional_data)
{
	int i;
	
	for (i=0; i<number_data_points; i++)
	{  
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma))+B 
		x[i] = fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2]))+fit_parameter[3];
	}
}

void jacobian_fit_function(double *fit_parameter, double *jacobian, int number_fit_parameters, int number_data_points, void *additional_data)
{
	int i, j;
	
	for (i=j=0; i<number_data_points; i++)
	{
		//exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma))
		jacobian[j++] = exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/(2*fit_parameter[2]*fit_parameter[2]));
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma)) * (X-X0)/(Sigma*Sigma)
		jacobian[j++] = fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2])) * (i-fit_parameter[1]) / (fit_parameter[2]*fit_parameter[2]);
		//A*exp(-((X-X0)*(X-X0))/(2*Sigma*Sigma)) * (X-X0)*(X-X0)/(Sigma*Sigma*Sigma)
		jacobian[j++] = fit_parameter[0]*exp(-(i-fit_parameter[1])*(i-fit_parameter[1])/
			(2*fit_parameter[2]*fit_parameter[2])) * (i-fit_parameter[1])*(i-fit_parameter[1]) / (fit_parameter[2]*fit_parameter[2]*fit_parameter[2]);
		jacobian[j++] = 1;
	}
}

/* model to be fitted to measurements: x_i = p[0]*exp(-p[1]*i) + p[2], i=0...n-1 */
void expfunc(double *fit_parameter, double *x, int number_fit_parameters, int number_data_points, void *additional_data)
{
register int i;

  for (i=0; i<number_data_points; ++i){
    x[i]=fit_parameter[0]*exp(-fit_parameter[1]*i) + fit_parameter[2];
  }
}

/* Jacobian of expfunc() */
void jacexpfunc(double *fit_parameter, double *jacobian, int number_fit_parameters, int number_data_points, void *additional_data)
{   
register int i, j;
  
  /* fill Jacobian row by row */
  for(i=j=0; i<number_data_points; ++i){
    jacobian[j++]=exp(-fit_parameter[1]*i);
    jacobian[j++]=-fit_parameter[0]*i*exp(-fit_parameter[1]*i);
    jacobian[j++]=1.0;
  }
}

/*
void check_jacobian(void)
{
	const int number_data_points = 40, number_fit_parameters = 4;
	double fit_parameter[number_fit_parameters], x[number_data_points];
	int i;
	
	dlevmar_chkjac(fit_function, jacobian_fit_function, fit_parameter, number_fit_parameters, number_data_points, NULL, x);
	
	for (i=0; i<number_data_points; i++)
	{
		printf("Jacobian: %.2f\n", x[i]);
	}
	//if Jacobian <0.5, than an element contains an error
}
*/		

void test(void)
{
	fitfunc(panelHandle);
}


void test3(void)
{
	double data[100] = {0.655000033,0.661250033,0.661250033,0.664375032,0.658125033,0.670625032,0.667500032,0.667500032,0.664375032,0.667500032,0.664375032,0.673750031,0.670625032,
		0.670625032,0.673750031,0.680000031,0.676875031,0.676875031,0.673750031,0.68312503,0.68625003,0.698750029,0.701875028,0.692500029,0.701875028,0.705000028,
		0.708125028,0.720625027,0.720625027,0.736250025,0.755000023,0.745625024,0.764375022,0.767500022,0.770625021,0.78000002,0.805000018,0.801875018,0.817500017,
		0.817500017,0.848750013,0.88000001,0.930000005,0.936250004,0.958125002,0.958125002,0.967500001,0.967500001,0.976875,1.001874998,1.014374996,1.023749996,
		1.045624993,1.029999995,1.017499996,0.995624998,1.001874998,0.992499999,0.964375002,0.926875005,0.914375007,0.88625001,0.876875011,0.855000013,0.820625016,
		0.795625019,0.761250022,0.726875026,0.723750026,0.714375027,0.701875028,0.692500029,0.695625029,0.701875028,0.692500029,0.68937503,0.68625003,0.673750031,0.680000031,
		0.680000031,0.673750031,0.673750031,0.670625032,0.670625032,0.670625032,0.664375032,0.661250033,0.658125033,0.658125033,0.661250033,0.661250033,0.661250033,
		0.655000033,0.664375032,0.670625032,0.664375032,0.661250033,0.661250033,0.667500032,0.667500032};	
	
	const int number_data_points=100, number_fit_parameters=4; // 40 measurements, 3 parameters
	double fit_parameter[number_fit_parameters], fit_data[number_data_points], info[LM_INFO_SZ];
	int ret;
	const int number_of_iterations = 100;
	
	/*
	[0] = Amplitude
	[1] = X0
	[2] = Sigma
	[3] = Background
	*/
	fit_parameter[0] = 1;
	fit_parameter[1] = 50;
	fit_parameter[2] = 5;
	fit_parameter[3] = 50;
	
	ret=dlevmar_der(fit_function, jacobian_fit_function, fit_parameter, data, number_fit_parameters, number_data_points, number_of_iterations, NULL, info, NULL, NULL, NULL);
	
	ret = 100;
	PlotY(panelHandle, PANEL_GRAPH, data, 100, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED); 
	
	fit_function(fit_parameter, data, number_fit_parameters, number_data_points, NULL);
	PlotY(panelHandle, PANEL_GRAPH, data, 100, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_GREEN); 
}


void test2(void)
{
	double data[100];
	const int number_data_points=100, number_fit_parameters=4; // 40 measurements, 3 parameters
	double fit_parameter[number_fit_parameters], fit_data[number_data_points], info[LM_INFO_SZ];
	int ret;
	const int number_of_iterations = 100;
	
	/*
	[0] = Amplitude
	[1] = X0
	[2] = Sigma
	[3] = Background
	*/
	fit_parameter[0] = 1;
	fit_parameter[1] = 50;
	fit_parameter[2] = 5;
	fit_parameter[3] = 50;
	
	ret=dlevmar_der(fit_function, jacobian_fit_function, fit_parameter, data, number_fit_parameters, number_data_points, number_of_iterations, NULL, info, NULL, NULL, NULL);
	
	ret = 100;
	PlotY(panelHandle, PANEL_GRAPH, data, 100, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED); 
	
	fit_function(fit_parameter, data, number_fit_parameters, number_data_points, NULL);
	PlotY(panelHandle, PANEL_GRAPH, data, 100, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_GREEN); 
}



void expfit(void)
{
	const int number_data_points=40, number_fit_parameters=3; // 40 measurements, 3 parameters
	double fit_parameter[number_fit_parameters], fit_data[number_data_points], opts[LM_OPTS_SZ], info[LM_INFO_SZ], sigma_params[number_fit_parameters], r_squared;
	register int i;
	int ret;
  	double err[number_data_points]; 
	const int number_of_iterations = 100;
	double *working_memory;
	double covar[number_fit_parameters*number_fit_parameters];
		
	//working_memory = malloc((LM_DIF_WORKSZ(number_fit_parameters, number_data_points)+number_fit_parameters*number_fit_parameters)*sizeof(double));
	working_memory = malloc(LM_DER_WORKSZ(number_fit_parameters, number_data_points)*sizeof(double));
	if(!working_memory)
	{
    	fprintf(stderr, "memory allocation request failed in main()\n");
      	exit(1);
    }
	
	/* generate some measurement using the exponential model with
	 * parameters (5.0, 0.1, 1.0), corrupted with zero-mean
	 * Gaussian noise of s=0.1
	 */
	//INIT_RANDOM(0);
	for(i=0; i<number_data_points; ++i)
	  fit_data[i]=(5.0*exp(-0.1*i) + 1.0) + gNoise(0.0, 0.1);
	
	//dlevmar_chkjac(expfunc, jacexpfunc, fit_parameter, number_fit_parameters, number_data_points, NULL, x);
  
	/* initial parameters estimate: (1.0, 0.0, 0.0) */
	fit_parameter[0]=1.0; fit_parameter[1]=0.0; fit_parameter[2]=0.0;

	/* optimization control parameters; passing to levmar NULL instead of opts reverts to defaults */
	opts[0]=LM_INIT_MU; opts[1]=1E-15; opts[2]=1E-15; opts[3]=1E-20;
	opts[4]=LM_DIFF_DELTA; // relevant only if the finite difference Jacobian version is used 

  
  
	/* invoke the optimization function */
	ret=dlevmar_der(expfunc, jacexpfunc, fit_parameter, fit_data, number_fit_parameters, number_data_points, number_of_iterations, opts, info, working_memory, covar, NULL); // with analytic Jacobian
	//ret=dlevmar_dif(expfunc, fit_parameter, fit_data, number_fit_parameters, number_data_points, 1000, opts, info, NULL, NULL, NULL); // without Jacobian
	sigma_params[0] = dlevmar_stddev(covar, number_fit_parameters, 0) ;
	sigma_params[1] = dlevmar_stddev(covar, number_fit_parameters, 1) ;
	sigma_params[2] = dlevmar_stddev(covar, number_fit_parameters, 2) ;
	
	r_squared = dlevmar_R2(expfunc, fit_parameter, fit_data,number_fit_parameters, number_data_points, NULL);
	
	printf("Levenberg-Marquardt returned in %g iter, reason %g, sumsq %g [%g]\n", info[5], info[6], info[1], info[0]);
	printf("Best fit parameters: %.7g +- %.7g. %.7g +- %.7g. %.7g +- %.7g. R2 = %.7g\n", fit_parameter[0], sigma_params[0], fit_parameter[1], sigma_params[1], fit_parameter[2], sigma_params[2], r_squared);

	
	free(working_memory);
	
}



/*------------------------------------------------------------------------------------------------------------------------
 *
 *			UI Callbacks
 *
-----------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------------------------------
	Function		clientmodecallback
					
	Description		Button 'Start / Stop Clientmode' on panel pressed
------------------------------------------------------------------------------------------------------------------------*/
int CVICALLBACK clientmodecallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			break;
	}
	return 0;
}

/*------------------------------------------------------------------------------------------------------------------------
	Function		panelCB
					
	Description		User closes UI
------------------------------------------------------------------------------------------------------------------------*/
int CVICALLBACK panelCB (int panel, int event, void *callbackData,
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
        QuitUserInterface (0);
    return 0;
}

/*------------------------------------------------------------------------------------------------------------------------
	Function		changecallback
					
	Description		Value of constant changed
------------------------------------------------------------------------------------------------------------------------*/
int CVICALLBACK changecallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			//Update_value();
			break;
	}
	return 0;
}

/*------------------------------------------------------------------------------------------------------------------------
	Function		main
					
	Description		Main function
------------------------------------------------------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    int error = 0;
    
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (panelHandle = LoadPanel (0, "Example.uir", PANEL));
	
	// init GUI
		
    /* display the panel and run the user interface */
    errChk (DisplayPanel (panelHandle));
    
	//test();
	//test3();
	expfit();
	
	
	errChk (RunUserInterface ());
	

	
		
Error:
    /* clean up */
    DiscardPanel (panelHandle);
    return 0;
}
