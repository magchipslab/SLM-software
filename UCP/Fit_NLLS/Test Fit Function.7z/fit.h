void fitfunc(int handle);
